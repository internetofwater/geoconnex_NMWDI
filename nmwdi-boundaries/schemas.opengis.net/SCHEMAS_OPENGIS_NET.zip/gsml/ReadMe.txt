-----------------------------------------------------------------------
OGC(r) Geoscience Markup Language 4.1 (GeoSciML) – ReadMe.txt
-----------------------------------------------------------------------

More information on the OGC Web Coverage Service Interface schema standard
may be found at
 http://www.opengeospatial.org/standards/geosciml

The most current schema is available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

Change history:

2018-03-09  GeoSciML Modeling Team
  * v4.1: post GeoSciML 4.1.1 as gsml/4.1 (OGC 16-008r1)

2017-02-07  Eric Boisvert
  * v4.1: post GeoSciML 4.1.0 as gsml/4.1 (OGC 16-008)

Note: check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available at
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c)
 - Open GeoSpatial Consortium (OGC), 2016-2018
 - IUGS Commission for the Management and Application of Geoscience Information, 2016-2017.
All rights reserved.

-----------------------------------------------------------------------

